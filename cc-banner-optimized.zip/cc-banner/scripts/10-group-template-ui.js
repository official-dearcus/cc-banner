/* CC 배너 제너레이터 — 10-group-template-ui
   원본 index.html 에서 기능별로 분리. 로드 순서가 곧 실행 순서다. */
      /* ---------- 초기화 · 제품군 선택 (명세서 §2.1.1) ---------- */
      function renderGroupButtons(filter) {
        const q = (filter || "").trim().toLowerCase();
        const box = $("#group");
        const entries = Object.entries(G()).filter(
          ([k, g]) => !q || g.label.toLowerCase().includes(q),
        );
        box.innerHTML = entries
          .map(
            ([k, g]) =>
              `<button class="groupbtn ${k === state.group ? "on" : ""}" data-g="${k}"${g.templates.length ? "" : ' data-empty="1"'}>${g.label}${g.templates.length ? "" : " · 템플릿없음"}</button>`,
          )
          .join("");
        box.querySelectorAll(".groupbtn").forEach(
          (b) => (b.onclick = () => selectGroup(b.dataset.g)),
        );
      }
      /* select=false 면 버튼만 다시 그린다. 호출부에서 selectGroup 을 따로 부르는 경우
         제품군 선택이 두 번 실행돼 랜덤(템플릿·컬러·히어로)이 두 번 돌던 문제를 막는다. */
      function initGroups(select) {
        renderGroupButtons();
        if (select === false) return;
        const keys = Object.keys(G());
        selectGroup(keys.includes("bamboo500") ? "bamboo500" : keys[0]);
      }
      /* 히어로 상태 완전 초기화 (템플릿 전환·제품군 전환 시) */
      function clearHero() {
        state.hero = null;
        state.heroSrc = "";
        state.heroUrl = "";
        state.heroUpload = false;
        state.heroTainted = false;
      }
      /* 처음 진입 시 템플릿을 랜덤으로 고른다 — 선택 고민을 줄이되, 이후 수정 가능 */
      function pickInitialTpl(g) {
        if (!g.templates || !g.templates.length) return null;
        return g.templates[Math.floor(Math.random() * g.templates.length)];
      }
      /* 처음 진입 시 컬러도 랜덤 (템플릿 허용 컬러 중, 수정 가능) */
      function pickInitialTheme(key, tpl) {
        if (!tpl) return null;
        const keys = Object.keys(themesForKey(key, tpl));
        if (!keys.length) return null;
        return keys[Math.floor(Math.random() * keys.length)];
      }
      /* 처음 진입 시 히어로도 랜덤 (현재 템플릿의 히어로 중에서만, 수정 가능).
         async 로딩 중 템플릿이 바뀌면 적용하지 않아 01/02 히어로가 섞이지 않는다. */
      async function applyRandomHero(gen) {
        const tplAtPick = state.tpl;
        const list = heroesForTpl();
        if (!list.length) return;
        const h = list[Math.floor(Math.random() * list.length)];
        if (!h || !h.url) return;
        try {
          const r = await loadImgSmart(h.url);
          if (gen !== undefined && gen !== SEL_GEN) return; // 제품군이 바뀌었으면 폐기
          if (state.tpl !== tplAtPick) return; // 로딩 후에도 같은 템플릿일 때만 적용
          state.hero = r.img;
          state.heroTainted = r.tainted;
          state.heroUrl = h.url;
          state.heroUpload = false;
          renderHeroList();
          drawTplPreviews();
          draw();
        } catch (e) {
          /* 실패 시 히어로 없이 진행 */
        }
      }
      let SEL_GEN = 0; // 제품군 선택 세대 — 비동기 로딩 경합 방지
      function selectGroup(key) {
        const gen = ++SEL_GEN;
        state.group = key;
        const g = G()[key];
        // 하위 선택 초기화 (§2.1.1)
        state.tpl = pickInitialTpl(g); // 처음엔 랜덤 (수정 가능)
        state.theme = pickInitialTheme(key, state.tpl); // 컬러도 랜덤 (수정 가능)
        clearHero();
        // 셀러명·공구기간은 운영자 입력값(가변값)이므로 제품군을 바꿔도 유지한다.
        Object.assign(state, {
          seller: state.seller || g.seller || "",
          copy: g.copy || "",
          copyBold: g.copyBold || "",
          series: g.series || g.seriesTitle || "",
          rows: (g.rows || []).map((r) =>
            mkRow({ ...r, thumb: null, thumbSrc: "" }),
          ),
        });
        applyTplDefaults();
        renderGroupButtons($("#groupSearch") ? $("#groupSearch").value : "");
        $("#seller").value = state.seller;
        $("#copy").value = state.copy;
        $("#copyBold").value = state.copyBold;
        // 누볼라 계열: 안내 문구·사이즈 이미지는 템플릿별 → 그룹 공통 순
        state.notice =
          (g.noticeByTpl && g.noticeByTpl[state.tpl]) || g.noticeText || "";
        state.sizeInfoOn = !!nvSizeInfoUrl();
        renderNvBlocks();
        $("#series").value = state.series;
        renderTplList();
        renderThemes();
        renderRows();
        syncTplUI();
        resetColorPick();
        renderNvBlocks();
        renderHeroList();
        draw();
        loadSheetImages(gen);
        applyRandomHero(gen);
      }
      function themesForKey(gk, tpl) {
        const g = G()[gk],
          all = themeTable((g && g.family) || "bamboo", tpl);
        const f = g && g.themeFilter && g.themeFilter[tpl];
        if (!f || !f.length) return all;
        const out = {};
        f.forEach((k) => {
          if (all[k]) out[k] = all[k];
        });
        return Object.keys(out).length ? out : all;
      }
      /* 시트의 thumbUrl / heroUrl 자동 로드 (§리스크: URL 만료·CORS) */
      async function loadSheetImages(gen) {
        const g = G()[state.group];
        if (!g) return;
        const fails = [];
        await Promise.all(
          state.rows.map(async (r) => {
            if (!r.thumbUrl || r.thumb) return;
            try {
              const x = await loadImgSmart(r.thumbUrl);
              r.thumb = x.img;
              r.thumbTainted = x.tainted;
              r.thumbSrc = r.thumbUrl;
            } catch (e) {
              fails.push(rowName(r));
            }
          }),
        );
        if (g.heroUrl && !state.hero) {
          try {
            const x = await loadImgSmart(g.heroUrl);
            state.hero = x.img;
            state.heroTainted = x.tainted;
            state.heroUpload = false;
          } catch (e) {
            fails.push("히어로");
          }
        }
        /* 색상 칩 이미지 (누볼라 등) */
        await Promise.all(
          ((g.colors) || []).map(async (c) => {
            if (!c.url || c.img) return;
            try {
              const x = await loadImgSmart(c.url);
              c.img = x.img;
              c.imgTainted = x.tainted;
            } catch (e) {
              fails.push("색상 " + (c.label || c.colorKey));
            }
          }),
        );
        /* 03 상단 4컷 이미지 */
        const gUrls = new Set();
        Object.values(g.gridByTpl || {}).forEach((arr) =>
          (arr || []).forEach((u) => u && gUrls.add(u)),
        );
        await Promise.all(
          [...gUrls].map(async (u) => {
            if (GRID_IMG[u]) return;
            try {
              const x = await loadImgSmart(u);
              GRID_IMG[u] = x.img;
            } catch (e) {
              fails.push("상단 이미지");
            }
          }),
        );
        /* 사이즈 안내 이미지 — 템플릿마다 다를 수 있어 URL 단위로 캐시 */
        const sUrls = new Set();
        if (g.sizeInfoUrl) sUrls.add(g.sizeInfoUrl);
        Object.values(g.sizeInfoByTpl || {}).forEach((u) => u && sUrls.add(u));
        await Promise.all(
          [...sUrls].map(async (u) => {
            if (SIZE_IMG[u]) return;
            try {
              const x = await loadImgSmart(u);
              SIZE_IMG[u] = x.img;
            } catch (e) {
              fails.push("사이즈 안내");
            }
          }),
        );
        if (fails.length)
          status(
            `이미지 ${fails.length}건 로드 실패: ${fails.slice(0, 2).join(", ")}`,
            1,
          );
        if (gen !== undefined && gen !== SEL_GEN) return; // 이미 다른 제품군으로 넘어감
        renderRows();
        draw();
      }
      function applyTplDefaults() {
        const g = G()[state.group];
        if (!g || !state.tpl) return;
        // 히어로 타이틀: 시트(TemplateMaster.heroTitle) 우선 → 내장 샘플 → 기존 입력 유지
        const st = g.titleByTpl && g.titleByTpl[state.tpl];
        if (st && st.length) {
          // 1줄 = 윗줄, 2줄 이후는 모두 아랫줄로 합친다(줄바꿈 유지).
          // 3줄 이상 입력해도 잘리지 않는다.
          state.t1 = st[0] || "";
          state.t2 = st.slice(1).filter(Boolean).join("\n");
        } else if (state.tpl === "02") {
          state.t1 = g.t1_02 || g.t1 || state.t1 || "";
          state.t2 = g.t2_02 || g.t2 || state.t2 || "";
        } else {
          state.t1 = g.t1 || state.t1 || "";
          state.t2 = g.t2 || state.t2 || "";
        }
        // 하단 카피 (02)
        const sc = g.copyByTpl && g.copyByTpl[state.tpl];
        if (sc && (sc.c || sc.b)) {
          state.copy = sc.c || "";
          state.copyBold = sc.b || "";
        }
        $("#copy").value = state.copy;
        $("#copyBold").value = state.copyBold;
        state.series =
          state.tpl === "02"
            ? g.optionTitleEn || g.series || ""
            : g.seriesTitle || g.series || "";
        $("#t1").value = state.t1;
        $("#t2").value = state.t2;
        $("#series").value = state.series;
        const lab = $("#seriesLabel");
        if (lab)
          lab.textContent =
            state.tpl === "02" ? "옵션 제목 (영문)" : "시리즈 제목 (한글)";
        // 누볼라 계열: 안내 문구·사이즈 이미지는 템플릿마다 다르므로 전환 시 다시 반영
        if (nvIsOn()) {
          state.notice =
            (g.noticeByTpl && g.noticeByTpl[state.tpl]) || g.noticeText || "";
          state.sizeInfoOn = !!nvSizeInfoUrl();
        }
        renderNvBlocks();
      }
      /* 템플릿 목록 — 프리뷰 카드 (§2.1.2) */
      function renderTplList() {
        const g = G()[state.group],
          box = $("#tplList");
        if (!g.templates.length) {
          box.innerHTML = `<div class="tplempty">이 제품군은 <b>템플릿이 아직 등록되지 않았습니다.</b><br/>
      피그마에 템플릿을 만들고 design.md에 규격을 추가하면 여기 표시됩니다.</div>`;
          $("#tplHint").textContent = "";
          return;
        }
        box.innerHTML = g.templates
          .map(
            (t) => `
    <div class="tplcard ${t === state.tpl ? "on" : ""}" data-t="${t}">
      <canvas class="tplprev" data-prev="${t}" width="240" height="302"></canvas>
      <div class="tplmeta"><div class="tplname">${(G()[state.group]?.labelOverride?.[t]) || tplMeta(curFam(), t).label}</div>
        <div class="tpldesc">${tplMeta(curFam(), t).desc}</div></div>
    </div>`,
          )
          .join("");
        box.querySelectorAll(".tplcard").forEach(
          (el) =>
            (el.onclick = () => {
              const prev = state.tpl;
              state.tpl = el.dataset.t;
              if (state.tpl !== prev) clearHero(); // 템플릿마다 히어로 성격이 다르므로 초기화
              if (!themesForKey(state.group, state.tpl)[state.theme])
                state.theme = Object.keys(
                  themesForKey(state.group, state.tpl),
                )[0];
              applyTplDefaults();
              renderTplList();
              renderThemes();
              syncTplUI();
              renderHeroList();
              draw();
            }),
        );
        requestAnimationFrame(drawTplPreviews);
      }
      /* 각 템플릿 히어로를 축소 렌더 */
      function drawTplPreviews() {
        const g = G()[state.group];
        if (!g.templates.length) return;
        const off = document.createElement("canvas");
        off.width = 860;
        off.height = SHARED.HERO_H;
        const octx = off.getContext("2d");
        g.templates.forEach((t) => {
          const cv = document.querySelector(`[data-prev="${t}"]`);
          if (!cv) return;
          const th =
            THEMES[t][
              THEMES[t][state.theme] ? state.theme : Object.keys(THEMES[t])[0]
            ];
          octx.clearRect(0, 0, 860, SHARED.HERO_H);
          const saveT = state.tpl;
          state.tpl = t;
          try {
            t === "01" ? hero01(octx, 860, th) : hero02(octx, 860, th);
          } catch (e) {}
          state.tpl = saveT;
          const c = cv.getContext("2d");
          c.clearRect(0, 0, cv.width, cv.height);
          c.drawImage(off, 0, 0, 860, SHARED.HERO_H, 0, 0, cv.width, cv.height);
        });
      }
      function syncTplUI() {
        const has = !!state.tpl;
        $("#themeBlock").hidden = !has;
        $("#copyBlock").hidden = nvIsOn() || state.tpl !== "02";
        $("#tplTag").textContent =
          G()[state.group].label +
          (has ? " · " + tplMeta(curFam(), state.tpl).label : "");
        $("#tplHint").innerHTML = !has
          ? ""
          : state.tpl === "01"
            ? "<b>셀러명은 영문만</b> 가능합니다 (High Summit)."
            : "셀러명 한글 가능 (Pretendard).";
        renumberBlocks();
        $("#imgLabel").textContent =
          state.tpl === "02"
            ? "제품 이미지 (누끼컷)"
            : "히어로 이미지 (연출컷)";
        $("#imgHint").innerHTML =
          state.tpl === "02"
            ? "그라데이션 배경 위에 얹힙니다. <b>배경 제거된 누끼컷</b>을 넣으세요."
            : "화면 전체를 채웁니다. <b>글자 없는 연출컷</b>을 넣으세요.";
        checkSeller();
      }
      function themesFor(tpl) {
        const g = G()[state.group];
        const all = THEMES[tpl];
        const f = g.themeFilter && g.themeFilter[tpl];
        if (!f || !f.length) return all;
        const out = {};
        f.forEach((k) => {
          if (all[k]) out[k] = all[k];
        });
        return Object.keys(out).length ? out : all;
      }
      function renderThemes() {
        if (!state.tpl) {
          $("#themeSw").innerHTML = "";
          return;
        }
        const t = themesFor(state.tpl);
        if (!t[state.theme]) state.theme = Object.keys(t)[0];
        $("#themeSw").innerHTML = Object.entries(t)
          .map(
            ([k, v]) => `
    <div class="sw ${k === state.theme ? "on" : ""}" data-k="${k}">
      <div class="dot" style="background:${v.accent}"></div><div class="nm">${v.label}</div></div>`,
          )
          .join("");
        $("#themeSw")
          .querySelectorAll(".sw")
          .forEach(
            (el) =>
              (el.onclick = () => {
                state.theme = el.dataset.k;
                renderThemes();
                drawTplPreviews();
                draw();
              }),
          );
      }
